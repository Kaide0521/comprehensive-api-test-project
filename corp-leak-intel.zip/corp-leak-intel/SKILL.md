---
name: corp-leak-intel
description: Passive threat intelligence collection for enterprise information leaks. Use when given company keywords (name, domain, email format, product names, GitHub org) to search public sources for leaked credentials, internal data, and sensitive exposures. Covers paste sites, code repositories, document libraries, credential databases, forums, and public threat intel indexes.
license: MIT
compatibility: Requires Claude Code with WebSearch and WebFetch tools. Python 3 required for report generation.
allowed-tools: Bash Read Write Edit Glob Grep Task WebFetch WebSearch
metadata:
  user-invocable: "true"
---

# 企业信息泄漏被动式威胁情报收集

## 概述

本 Skill 在不做任何主动扫描的前提下，利用 Google Dork 和公开 API 对多个开源情报源进行系统性搜索，发现与目标企业相关的信息泄漏，并生成结构化风险报告。

**原则**：只读 / 被动 / 不触发目标系统。

---

## 第一步：读取目标配置

直接读取 `target.json`，不需要交互式参数收集。

```
target_config = load(target.json)
keywords      = target_config["watch_keywords"]   # T1/T2/T3 分级
source_tiers  = target_config["source_tiers"]     # 各级对应的源范围
sources       = load(references/sources_matrix.json)
credentials   = load(.credentials.json)            # gitlab_token / gitee_token
```

**关键词分级说明**：

| 级别 | 特征 | 查询范围 |
|------|------|---------|
| T1_internal | 内部术语/邮箱域，外部极难随机出现 | 全部源 |
| T2_brand | 品牌名/产品名 | 全部源 |
| T3_generic | 通用简称（噪音较多） | 仅高信噪比源（代码仓库+粘贴板+暗网） |

如需新增关键词，直接编辑 `target.json` 对应 tier 数组即可，无需改动其他文件。

---

## 第二步：关键词 × 源 矩阵执行

### 配置文件读取

1. 从目标配置（`target.json`）读取 `watch_keywords`，按 T1/T2/T3 三级分组
2. 从 [`references/sources_matrix.json`](references/sources_matrix.json) 读取全部源列表

### 执行矩阵规则

```
for each tier in [T1_internal, T2_brand, T3_generic]:
    for each keyword in watch_keywords[tier]:
        for each source in sources（按 source_tiers 过滤）:
            执行 source.template.replace("{keyword}", keyword)
            若有结果 → 抓取前3个URL → 提取片段 → 告警
```

**分级执行说明**：

| 级别 | 关键词特征 | 查询范围 | 误报预期 |
|------|-----------|---------|---------|
| T1_internal | 内部术语/域名，外部极难随机出现 | 全部源 | 极低，命中即告警 |
| T2_brand | 品牌名/产品名 | 全部源 | 较低 |
| T3_generic | 通用简称（如「银联」） | 仅高信噪比源（代码仓库+粘贴板+暗网） | 较高，需人工确认 |

**每条查询执行规则**：
- `method: websearch` → 用 `WebSearch` 执行，取前3个结果URL
- `method: webfetch` → 直接用 `WebFetch` 访问 API/搜索页
- 对每个结果URL用 `WebFetch` 抓取内容，提取包含关键词的片段（≤300字符）
- 命中 → 记入 findings；0结果 → 记入 no_findings
- 搜索间隔 ≥ 2秒，避免触发反爬

### ⚠️ Pastebin 特别说明

`site:pastebin.com` 只能发现**已被 Google 索引**的 paste。
`pastebin.com/XXXXXXXX` 直链分享的 paste 不会出现在搜索结果中。

完整覆盖需同时执行：
1. `site:pastebin.com "{keyword}"` — Google 历史索引
2. `psbdmp.ws/search/{keyword}` — 第三方存档（WebFetch）
3. Pastebin Scraping API — 实时新 paste 流（需 PRO 账号）

---

## 第三步：证据分类与风险评级

对每条提取的证据片段，按以下规则打标：

### 🔴 高风险 —— 凭据 / 密钥泄漏

**触发条件**（满足任一）：
- 包含 API key、secret、token、password、private_key、access_key
- 匹配正则模式：`[A-Za-z0-9+/]{40,}=*`（Base64 密钥）、`ghp_[A-Za-z0-9]{36}`（GitHub PAT）、`AKIA[A-Z0-9]{16}`（AWS key）、`sk-[A-Za-z0-9]{48}`（OpenAI key）
- 包含数据库连接字符串：`mysql://`、`postgresql://`、`mongodb+srv://`
- 包含私钥头：`-----BEGIN RSA PRIVATE KEY-----`
- 包含大批量用户名 + 密码组合（credential dump 特征）

**处置建议**：立即轮换相关凭据；审计访问日志；通知安全团队

### 🟡 中风险 —— 内部信息暴露

**触发条件**（满足任一）：
- 内网 IP 段（10.x、172.16-31.x、192.168.x）或内部主机名
- 内部系统截图 / 文档（含 "internal"、"confidential"、"staging"、"prod" 等标签）
- 员工真实姓名 + 职位 + 联系方式（HR 数据特征）
- 内部项目代号、架构图、部署配置
- 大量真实邮箱地址（> 10 条来自同一 dump）
- 源码片段（非公开仓库特征：含内部注释、TODO、内部域名引用）

**处置建议**：评估信息时效性；通知数据所有者；考虑 DMCA 下架请求

### 🟢 低风险 —— 一般提及

**触发条件**：
- 公司名 / 域名的普通讨论、新闻报道、评测文章
- 公开邮箱（sales@、info@、support@ 等通用前缀）
- 公开文档中的公司 Logo / 品牌引用
- 无敏感内容的技术讨论

**处置建议**：记录存档；无需立即行动；监控后续变化

---

## 第四步：调用报告生成脚本

将收集到的证据整理为 JSON 结构，调用 `scripts/report_builder.py` 生成最终报告：

```bash
python3 scripts/report_builder.py --input evidence.json --output report_YYYYMMDD.md
```

若无法运行脚本，直接在对话中输出 Markdown 格式报告（见第五步格式模板）。

---

## 第五步：输出报告格式

```markdown
# 企业信息泄漏情报报告

**目标**：{company_name} | {domain}
**生成时间**：{datetime}
**执行范围**：{source_count} 个情报源 | {dork_count} 条 Dork
**风险汇总**：🔴 {high} 条 | 🟡 {medium} 条 | 🟢 {low} 条

---

## 执行摘要

{2-3句总结：最严重发现、受影响系统、建议优先级}

---

## 🔴 高风险发现

### [{序号}] {标题}
- **来源**：{source_name}（{source_category}）
- **URL**：{url}
- **发现时间**：{date_found}
- **证据片段**：
  ```
  {evidence_snippet ≤300字符}
  ```
- **风险说明**：{why_risky}
- **处置建议**：{action}

---

## 🟡 中风险发现

{同上格式}

---

## 🟢 低风险 / 一般提及

{简表：| 序号 | 来源 | 摘要 | URL |}

---

## 未发现记录

{列出执行了但 0 结果的情报源}

---

## 附录：使用的 Dork 列表

{按分类列出所有执行的 Dork}

---

*本报告由被动情报收集生成，未对目标系统发起任何主动连接。*
*仅供授权安全评估使用。*
```

---

## 注意事项

1. **合法合规**：仅对授权目标执行，确保符合当地法律法规
2. **数据敏感性**：报告中的真实凭据应脱敏处理（显示前 4 位 + `****`）
3. **速率限制**：搜索间隔建议 2-5 秒，避免触发反爬机制
4. **误报过滤**：排除明显的测试数据（`example.com`、`test@test.com`）和同名无关公司
5. **时效性**：注明每条证据的发现/发布时间，评估信息是否已过期

---

## 快速参考：高价值 Dork 模板

```
# GitHub 密钥泄漏
site:github.com "{domain}" "api_key" OR "secret" OR "password"
site:gist.github.com "{email_format}" "token"

# Pastebin
site:pastebin.com "{domain}" "password" OR "username"
site:pastebin.com "{email_format}"

# 凭据数据库
site:dehashed.com "{domain}"
site:leakcheck.io "{domain}"

# Grep.app（代码全文）
# 访问 https://grep.app/search?q={domain}&filter[lang][0]=YAML

# Telegram 公开频道
site:t.me "{company_name}" "数据" OR "泄漏" OR "database"
```

完整 Dork 库见 [references/dorks.md](references/dorks.md)。
