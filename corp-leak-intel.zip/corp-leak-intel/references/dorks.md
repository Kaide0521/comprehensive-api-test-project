# 企业信息泄漏情报 — 完整 Dork 库

**占位符说明**：
- `{company}` — 公司名（英文）
- `{company_cn}` — 公司名（中文）
- `{domain}` — 主域名，如 `acme.com`
- `{domain_bare}` — 域名无 TLD，如 `acme`
- `{email}` — 邮箱后缀，如 `@acme.com`
- `{product}` — 产品名
- `{github_org}` — GitHub 组织名
- `{keyword}` — 任意关键词

---

## 1. 代码仓库类

### 1.1 GitHub（Web 搜索 Dork）

```
# 通用密钥泄漏
site:github.com "{domain}" "api_key" OR "apikey" OR "api_secret"
site:github.com "{domain}" "password" OR "passwd" OR "pwd"
site:github.com "{domain}" "secret_key" OR "secretkey" OR "client_secret"
site:github.com "{domain}" "access_token" OR "auth_token" OR "bearer"
site:github.com "{domain}" "private_key" OR "-----BEGIN RSA PRIVATE KEY-----"
site:github.com "{domain}" "db_password" OR "database_url" OR "DATABASE_URL"
site:github.com "{domain}" "aws_access_key_id" OR "AKIA"
site:github.com "{domain}" "smtp_password" OR "mail_password"

# .env 文件
site:github.com "{domain}" filename:.env
site:github.com "{email}" filename:.env
site:github.com "{domain_bare}" filename:.env "SECRET" OR "PASSWORD" OR "KEY"

# 配置文件
site:github.com "{domain}" filename:config.yml OR filename:config.json OR filename:settings.py
site:github.com "{domain}" filename:application.properties OR filename:application.yml
site:github.com "{domain}" filename:.npmrc OR filename:.pypirc OR filename:pip.conf
site:github.com "{domain}" filename:wp-config.php OR filename:database.php

# 连接字符串
site:github.com "{domain}" "mongodb+srv://" OR "mysql://" OR "postgresql://"
site:github.com "{domain}" "redis://" OR "amqp://" OR "jdbc:"

# 邮箱泄漏
site:github.com "{email}" -site:github.com/login
site:gist.github.com "{email}"
site:gist.github.com "{domain}" "password" OR "secret" OR "key"

# 内部信息
site:github.com "{company}" "internal" OR "confidential" OR "do not share"
site:github.com "{github_org}" fork:true language:Dockerfile
```

### 1.2 GitLab

> **重要**：`site:gitlab.com` 仅覆盖 Google 已索引内容，覆盖率低。
> 优先使用下方原生搜索 API（无需账号，直接 WebFetch）。

**原生搜索 API（WebFetch）**：
```
# Blob 全文搜索（最全面，直接搜索代码内容）
https://gitlab.com/search?search={domain}&scope=blobs
https://gitlab.com/search?search={email}&scope=blobs
https://gitlab.com/search?search={domain_bare}+password&scope=blobs
https://gitlab.com/search?search={domain_bare}+secret_key&scope=blobs
https://gitlab.com/search?search={domain_bare}+api_key&scope=blobs
https://gitlab.com/search?search={domain_bare}+access_token&scope=blobs
https://gitlab.com/search?search={domain_bare}+db_password&scope=blobs

# 项目搜索（查找相关仓库）
https://gitlab.com/explore/projects?search={company}
https://gitlab.com/explore/projects?search={domain_bare}

# GitLab API v4（JSON 返回，更易解析）
https://gitlab.com/api/v4/search?scope=blobs&search={domain}+password
https://gitlab.com/api/v4/search?scope=blobs&search={email}
https://gitlab.com/api/v4/search?scope=projects&search={company}
```

**Google Dork 补充**：
```
site:gitlab.com "{domain}" "api_key" OR "secret" OR "password"
site:gitlab.com "{domain}" filename:.env
site:gitlab.com "{email}" "token" OR "key"
site:gitlab.com "{company}" "internal" OR "staging" OR "prod"
site:gitlab.com "{domain}" "DB_PASSWORD" OR "DATABASE_URL"
site:gitlab.com "{domain}" "-----BEGIN" "PRIVATE KEY"
site:gitlab.com "{company_cn}" "密码" OR "密钥" OR "token"
```

### 1.3 Bitbucket

```
site:bitbucket.org "{domain}" "password" OR "secret" OR "api_key"
site:bitbucket.org "{email}"
site:bitbucket.org "{company}" filename:.env OR filename:config
```

### 1.4 Gitee（码云）

> **重要**：`site:gitee.com` Google 索引不完整（中文站点爬取率低）。
> 优先使用下方 Gitee 原生代码搜索。

**原生代码搜索（WebFetch）**：
```
# 代码全文搜索
https://search.gitee.com/?type=codes&q={domain}+password
https://search.gitee.com/?type=codes&q={domain}+secret
https://search.gitee.com/?type=codes&q={email}
https://search.gitee.com/?type=codes&q={domain_bare}+api_key
https://search.gitee.com/?type=codes&q={domain_bare}+access_token
https://search.gitee.com/?type=codes&q={company_cn}+密码
https://search.gitee.com/?type=codes&q={company_cn}+密钥
https://search.gitee.com/?type=codes&q={company_cn}+token

# 仓库搜索
https://search.gitee.com/?type=repository&q={company}
https://search.gitee.com/?type=repository&q={company_cn}

# Gitee API v5
https://gitee.com/api/v5/search/repositories?q={domain_bare}&sort=updated
```

**Google Dork 补充**：
```
site:gitee.com "{domain}" "password" OR "secret" OR "密码"
site:gitee.com "{company_cn}" "api_key" OR "token" OR "密钥"
site:gitee.com "{email}" filename:.env
site:gitee.com "{company}" "AccessKey" OR "SecretKey"
site:gitee.com "{domain}" "DB_PASSWORD" OR "DATABASE_URL"
site:gitee.com "{company_cn}" "内部" OR "测试账号" OR "生产环境"
```

### 1.5 CSDN Code / GitCode

```
site:gitcode.net "{domain}" "password" OR "secret"
site:code.csdn.net "{domain}" filename:.env
https://gitcode.net/search?search={domain}&scope=blobs   # 原生搜索
```

### 1.6 Grep.app（跨仓库全文搜索，覆盖 GitHub/GitLab/Bitbucket）

```
# 直接 WebFetch（速率限制：请求间隔 ≥5秒）
https://grep.app/search?q={domain}+password
https://grep.app/search?q={domain}+secret_key
https://grep.app/search?q={email}
https://grep.app/search?q=AKIA+{domain_bare}
https://grep.app/search?q={domain_bare}+DB_PASSWORD
https://grep.app/search?q={domain_bare}+access_token&filter[lang][0]=YAML
https://grep.app/search?q={domain_bare}+api_key&filter[lang][0]=Python
https://grep.app/search?q={domain_bare}+private_key
```

---

## 2. 粘贴板类

### ⚠️ 重要说明：Google Dork 的覆盖盲区

`site:pastebin.com` 的 Google Dork **只能发现已被 Google 爬取索引的 paste**。
未被索引的 paste（如 `pastebin.com/HIAGUSI` 这类直接链接分享的内容）**无法通过 Google Dork 发现**。

**真正全面的 Pastebin 监控需要以下三条路径同时覆盖：**

| 路径 | 覆盖范围 | 方法 |
|------|---------|------|
| A. Google Dork | 历史已索引内容 | `site:pastebin.com "{keyword}"` |
| B. psbdmp.ws | 历史存档（可搜索） | WebFetch 搜索接口 |
| C. Pastebin Scraping API | 实时新 paste 流 | 需 PRO 账号，按关键词过滤 |

### 2.1 Pastebin

**路径 A — Google Dork（历史索引）**：
```
site:pastebin.com "{domain}"
site:pastebin.com "{email}"
site:pastebin.com "{company}" "password" OR "username" OR "credential"
site:pastebin.com "{domain}" "dump" OR "leak" OR "breach"
site:pastebin.com "{domain}" "username" OR "login" OR "admin"
site:pastebin.com "{company_cn}" "密码" OR "泄漏" OR "数据库"
"{domain}" site:pastebin.com/archive
"{email}" site:pastebin.com/raw
```

**路径 B — psbdmp.ws（第三方 Pastebin 存档，可全文搜索）**：
```
# WebFetch 以下 URL（无需账号）：
https://psbdmp.ws/search/{domain}
https://psbdmp.ws/search/{email}
https://psbdmp.ws/search/{company}
https://psbdmp.ws/search/{company_cn}

# Google Dork 补充搜索 psbdmp 索引：
site:psbdmp.ws "{domain}"
site:psbdmp.ws "{email}"
```

**路径 C — Pastebin Scraping API（实时流，需 PRO 账号）**：
```
# 获取最新 100 条 paste（需 API Key）：
GET https://scrape.pastebin.com/api_scraping.php?limit=100
# 对每条 paste 用 key 字段拼接：
GET https://scrape.pastebin.com/api_scrape_item.php?i={paste_key}
# 然后本地关键词过滤（unionpay / @unionpay.com / 中国银联 / 银联）
```

### 2.2 Pastecode

```
site:pastecode.io "{domain}" "password" OR "token"
site:pastecode.io "{email}"
https://pastecode.io/search/?q={domain}   # 原生搜索
```

### 2.3 Rentry

```
site:rentry.co "{domain}"
site:rentry.org "{domain}" "password" OR "key"
```

### 2.4 Hastebin / Toptal

```
site:hastebin.com "{domain}"
site:hastebin.com "{email}"
```

### 2.5 JustPaste

```
site:justpaste.it "{domain}" "password" OR "credential"
site:justpaste.it "{email}"
```

### 2.6 ControlC

```
site:controlc.com "{domain}"
site:controlc.com "{email}" "password"
```

### 2.7 GhostBin

```
site:ghostbin.com "{domain}"
site:ghostbin.co "{email}" "token" OR "secret"
```

### 2.8 其他粘贴板

```
site:paste.ee "{domain}" "password" OR "key"
site:privatebin.net "{domain}"
site:0bin.net "{domain}"
site:ix.io "{domain}" "secret" OR "password"
site:termbin.com "{domain}"
site:dpaste.com "{domain}"
site:dpaste.org "{email}"
site:paste.fo "{domain}"
```

---

## 3. 凭据泄漏数据库类

### 3.1 Have I Been Pwned

```
# API 端点（需 API Key，企业版支持域名查询）：
GET https://haveibeenpwned.com/api/v3/breacheddomain/{domain}
Headers: hibp-api-key: {YOUR_API_KEY}

# 公开 Web 页面（WebFetch）：
https://haveibeenpwned.com/DomainSearch
```

### 3.2 IntelligenceX

```
# 公开搜索页（需登录后才能查看完整结果）：
https://intelx.io/?s={domain}
https://intelx.io/?s={email}

# Google Dork：
site:intelx.io "{domain}"
site:intelx.io "{email}"
```

### 3.3 Dehashed

```
site:dehashed.com "{domain}"
site:dehashed.com "email:{email}"
https://dehashed.com/search?query={domain}   # 需登录
```

### 3.4 LeakCheck

```
site:leakcheck.io "{domain}"
https://leakcheck.io/api/public?check={email}  # 公开 API（每日限额）
```

### 3.5 Snusbase（公开部分）

```
site:snusbase.com "{domain}"
```

### 3.6 BreachDirectory

```
https://breachdirectory.org/    # 公开查询（WebFetch）
site:breachdirectory.org "{domain}"
```

### 3.7 Exposed.vc / 威胁情报聚合

```
site:exposed.vc "{domain}"
site:databreach.com "{company}"
```

---

## 4. 文档 / 文库类

### 4.1 Google Docs（公开文档）

```
site:docs.google.com/document "{company}" "confidential" OR "internal"
site:docs.google.com/spreadsheets "{domain}" "password" OR "username"
site:docs.google.com "{email}" "employee" OR "staff" OR "HR"
site:drive.google.com "{company}" "budget" OR "salary" OR "roadmap"
site:docs.google.com/presentation "{company}" "internal" OR "Q1" OR "strategy"
```

### 4.2 Scribd

```
site:scribd.com "{company}" "confidential" OR "internal"
site:scribd.com "{domain}" "password" OR "infrastructure"
```

### 4.3 SlideShare

```
site:slideshare.net "{company}" "internal" OR "roadmap" OR "architecture"
site:slideshare.net "{company_cn}" "内部" OR "规划"
```

### 4.4 Issuu

```
site:issuu.com "{company}" "internal" OR "confidential"
```

### 4.5 百度文库

```
site:wenku.baidu.com "{company_cn}" "内部" OR "密码" OR "机密"
site:wenku.baidu.com "{company_cn}" "账号" OR "数据库"
```

### 4.6 豆丁网 / Doc88 / 道客巴巴

```
site:docin.com "{company_cn}" "内部" OR "机密"
site:docin.com "{domain}" "password" OR "secret"
site:doc88.com "{company_cn}" "内部文件"
```

---

## 5. 论坛 / 社区类

### 5.1 Reddit

```
site:reddit.com "{company}" "leak" OR "breach" OR "hacked"
site:reddit.com "{domain}" "credentials" OR "password" OR "data breach"
site:reddit.com/r/netsec "{company}"
site:reddit.com/r/hacking "{company}"
site:reddit.com/r/DataHoarder "{company}" "dump"
```

### 5.2 V2EX

```
site:v2ex.com "{company_cn}" "数据泄漏" OR "密码" OR "被黑"
site:v2ex.com "{domain}" "hack" OR "泄漏"
```

### 5.3 知乎

```
site:zhihu.com "{company_cn}" "数据泄漏" OR "信息安全事故"
site:zhihu.com "{company_cn}" "内鬼" OR "员工" OR "离职"
```

### 5.4 CSDN 博客

```
site:blog.csdn.net "{domain}" "密码" OR "数据库" OR "泄漏"
site:blog.csdn.net "{company_cn}" "安全漏洞" OR "数据泄漏"
```

### 5.5 52pojie（吾爱破解）

```
site:52pojie.cn "{company_cn}" "破解" OR "数据" OR "账号"
site:52pojie.cn "{domain}"
```

### 5.6 看雪（Pediy / Kanxue）

```
site:bbs.pediy.com "{company_cn}"
site:kanxue.com "{company}" "逆向" OR "数据"
```

### 5.7 Hack Forums / 黑客论坛

```
site:hackforums.net "{company}" "database" OR "dump"
site:hackforums.net "{domain}" "credentials"
```

### 5.8 Telegram 公开频道（Google Dork）

```
site:t.me "{company}" "数据" OR "泄漏" OR "database"
site:t.me "{company}" "leak" OR "breach" OR "dump"
site:t.me "{domain}" "password" OR "credential"
site:t.me/s "{company_cn}" "数据库" OR "账号密码"
```

---

## 6. 暗网镜像 / 威胁情报聚合

### 6.1 BreachForums 镜像

```
site:breachforums.is "{company}" OR "{domain}"
site:breachforums.com "{company}" "database" OR "dump"
"{company}" site:breachforums.st
```

### 6.2 RaidForums 镜像 / 存档

```
site:raidforums.com "{company}"
"{domain}" site:raidforums.com/Thread
```

### 6.3 CyberCrime Tracker（公开部分）

```
site:cybercrime-tracker.net "{domain}"
```

---

## 7. 邮箱 / 员工信息类（NEW）

> 用于发现员工邮箱、职位信息，支持鱼叉攻击面评估和泄漏邮箱比对。

### 9.1 Hunter.io（邮箱溯源）

```
# WebFetch（公开预览，无需账号）：
https://hunter.io/domain/{domain}

# API（需 API Key）：
https://api.hunter.io/v2/domain-search?domain={domain}&api_key={KEY}
```

### 9.2 Phonebook.cz

```
# WebFetch：
https://phonebook.cz/?q={domain}
```

### 9.3 LinkedIn（人员泄漏）

```
site:linkedin.com/in/ "{company}" "员工" OR "工程师" OR "开发"
site:linkedin.com "{company_cn}" "security" OR "engineer" OR "developer"

# 注：LinkedIn 搜索结果可揭示技术栈、内部项目名等敏感信息
```

### 9.4 社交媒体（Weibo / Twitter）

```
# 微博
site:weibo.com "{company_cn}" "数据泄漏" OR "安全漏洞" OR "被黑"
site:weibo.com "{company_cn}" "内部" OR "离职"

# Twitter/X
site:x.com "{company}" "breach" OR "leak" OR "hacked"
site:twitter.com "{domain}" "leak" OR "credential"
```

---

## 8. 招聘信息 / 技术栈泄漏类

> 招聘 JD 往往暴露内部技术架构、中间件版本、框架选型，是 OSINT 中经常被忽视的高价值来源。

### 10.1 拉勾网

```
site:lagou.com "{company_cn}"
# 关注技术栈关键词：数据库版本、中间件、内部平台名
```

### 10.2 Boss直聘

```
site:zhipin.com "{company_cn}"
```

### 10.3 51job

```
site:51job.com "{company_cn}"
```

### 10.4 LinkedIn Jobs

```
site:linkedin.com/jobs "{company}" "engineer" OR "developer" OR "security"
```

### 10.5 天眼查 / 企查查（企业信息）

```
# WebFetch：
https://www.tianyancha.com/search?key={company_cn}
https://www.qcc.com/search_list?key={company_cn}

# 可获取：注册信息、法人、股权结构、ICP 备案、关联公司
```

---

## 9. 专项凭据泄漏 Dork

### 11.1 AWS 密钥

```
"{domain}" "AKIA" site:github.com OR site:pastebin.com
"{company}" "aws_access_key_id" "aws_secret_access_key"
"{domain}" "AWSAccessKeyId" site:github.com
```

### 11.2 GitHub Personal Access Token

```
"{domain}" "ghp_" site:github.com OR site:pastebin.com
"{email}" "ghp_[A-Za-z0-9]"
```

### 11.3 OpenAI / Anthropic API Key

```
"{domain}" "sk-" "openai" site:github.com
"{company}" "OPENAI_API_KEY" site:github.com
```

### 11.4 Stripe / 支付密钥

```
"{domain}" "sk_live_" site:github.com OR site:pastebin.com
"{company}" "stripe_secret_key" site:github.com
```

### 11.5 数据库连接字符串

```
"{domain}" "mongodb+srv://" OR "mysql://" OR "postgresql://" site:github.com
"{company}" "DB_PASSWORD" filename:.env site:github.com
"{domain}" "redis://:{password}@"
```

### 11.6 Slack / 企业微信 / 钉钉 Webhook

```
"{domain}" "hooks.slack.com/services" site:github.com
"{company}" "xoxb-" OR "xoxp-" site:github.com
"{company}" "dingtalk" "webhook" "token" site:github.com
"{company_cn}" "钉钉" "webhook" site:github.com OR site:gitee.com
```

### 11.7 JWT Secret

```
"{domain}" "jwt_secret" OR "JWT_SECRET" site:github.com
"{company}" "jsonwebtoken" "secret" filename:.env site:github.com
```

---

## 10. 通用高覆盖 Dork 组合

```
# 密钥综合
"{domain}" ("api_key" OR "apiKey" OR "access_token" OR "secret_key" OR "private_key" OR "client_secret")

# 凭据综合
"{email}" ("password" OR "passwd" OR "pwd" OR "pass" OR "credential")

# 配置文件综合
"{domain}" (filetype:env OR filetype:cfg OR filetype:conf OR filetype:yaml OR filetype:yml) ("password" OR "secret")

# 内部信息综合
"{company}" ("internal use only" OR "confidential" OR "not for distribution" OR "proprietary")

# 中文泄漏综合
"{company_cn}" ("密码" OR "账号" OR "数据库" OR "内部" OR "机密" OR "泄漏")

# 暗网提及综合
"{company}" OR "{domain}" (site:breachforums.is OR site:raidforums.com OR site:t.me)
```

---

## 11. HIBP 域名查询端点

```
# 付费 API（需 API Key）
GET https://haveibeenpwned.com/api/v3/breacheddomain/{domain}
Headers:
  hibp-api-key: {YOUR_API_KEY}
  User-Agent: corp-leak-intel-scanner

# 返回该域名邮箱涉及的所有 breach 名称列表
# 再用以下端点获取 breach 详情：
GET https://haveibeenpwned.com/api/v3/breach/{breach_name}
```

---

## 12. 执行优先级速查表

| 优先级 | 类别 | 关键手段 | 说明 |
|--------|------|---------|------|
| P1 | GitLab 原生 API | `/api/v4/search?scope=blobs` | 覆盖率远超 site: dork |
| P1 | Gitee 原生搜索 | `search.gitee.com/?type=codes` | site: dork 在中文站覆盖率极低 |
| P1 | Pastebin 三路径 | Scraping API + psbdmp.ws + Google Dork | 缺一不可，Google Dork 仅覆盖已索引内容 |
| P1 | GitHub .env 泄漏 | `site:github.com filename:.env` | 最高密度凭据来源 |
| P1 | AWS Key | `"{domain}" "AKIA" site:github.com` | 可直接用于云端入侵 |
| P1 | DB 连接串 | `"{domain}" "mongodb+srv://"` | 直连数据库风险 |
| P2 | Gist 泄漏 | `site:gist.github.com "{email}"` | 常被忽视的高危来源 |
| P2 | Google Docs 内部文档 | `site:docs.google.com "{company}" "confidential"` | 误公开的内部文档 |
| P2 | Telegram 频道 | `site:t.me "{company}" "数据"` | 中文圈泄漏常见传播渠道 |
| P2 | Grep.app | `grep.app/search?q={domain}+password` | 跨仓库代码全文搜索 |
| P2 | 百度文库 / 豆丁 | `site:wenku.baidu.com "{company_cn}"` | 内部文档误上传 |
| P3 | BreachForums | Google 索引 Dork | 暗网索引有限，可作为补充 |
| P3 | 知乎 / V2EX | 中文社区讨论 | 泄漏事件二手传播 |
| P3 | Reddit | `site:reddit.com "{company}" "breach"` | 英文社区 |
| P3 | 招聘信息 | 拉勾 / Boss直聘 | 技术栈/内部平台名泄漏 |
| P3 | 天眼查 / 企查查 | 企业注册信息 | 关联公司/子公司发现 |
