#!/usr/bin/env python3
"""
corp-leak-intel 监控脚本

功能：
  - 读取 target.json 关键词 + sources_matrix.json 监控源
  - API 类（GitLab、Gitee、psbdmp.ws、grep.app）直接 HTTP 请求
  - Search 类（GitHub、Pastebin、Telegram 等）通过 DuckDuckGo 执行 Dork（免费无需 Key）
  - 结果去重（seen_findings.json），只记录新发现
  - 本次结果写入 results_YYYYMMDD_HHMMSS.json

用法：
  python3 scripts/monitor.py
  python3 scripts/monitor.py --target ~/Desktop/OSINT/unionpay_target.json
  python3 scripts/monitor.py --out ~/Desktop/OSINT/

定时调度（每6小时）：
  0 */6 * * * cd "/path/to/corp-leak-intel" && python3 scripts/monitor.py >> logs/monitor.log 2>&1

依赖：
  pip install requests duckduckgo-search
"""

import argparse
import hashlib
import json
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import quote, urlencode

try:
    import requests
except ImportError:
    sys.exit("[错误] pip install requests")

try:
    from ddgs import DDGS
except ImportError:
    try:
        from duckduckgo_search import DDGS
    except ImportError:
        sys.exit("[错误] pip install ddgs")


# ── 路径 ────────────────────────────────────────────────────────
SCRIPT_DIR   = Path(__file__).parent
BASE_DIR     = SCRIPT_DIR.parent
SOURCES_FILE = BASE_DIR / "references" / "sources_matrix.json"
CREDS_FILE   = BASE_DIR / ".credentials.json"
SEEN_FILE    = BASE_DIR / "data" / "seen_findings.json"
DEFAULT_OUT  = Path.home() / "Desktop" / "OSINT"


# ── 工具 ────────────────────────────────────────────────────────
def load_json(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def save_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def fid(url, keyword, snippet):
    raw = f"{url}|{keyword}|{snippet[:80]}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]

def ts():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def log(msg):
    print(f"[{ts()}] {msg}", flush=True)

def extract_context(text, keyword, window=200):
    """提取关键词周围片段。"""
    idx = text.lower().find(keyword.lower())
    if idx == -1:
        return text[:300]
    start = max(0, idx - 80)
    end   = min(len(text), idx + window)
    return text[start:end].strip()


# ── HTTP Session ─────────────────────────────────────────────────
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

S = requests.Session()
S.headers.update({"User-Agent": "Mozilla/5.0 (corp-leak-intel/2.0)"})

def get(url, headers=None, params=None, timeout=15):
    try:
        return S.get(url, headers=headers or {}, params=params or {}, timeout=timeout)
    except requests.RequestException as e:
        log(f"  请求失败 {url[:70]}: {e}")
        return None


# 不可 fetch 的域名（需登录/反爬/无意义）
_SKIP_FETCH_DOMAINS = {
    "scribd.com", "dehashed.com", "leakcheck.io",
    "wenku.baidu.com", "docin.com", "zhihu.com",
    "t.me", "breachforums.is",
}

def fetch_snippet(url, keyword):
    """尝试 fetch URL 并提取关键词周围片段。
    失败时返回 None，调用方回退到 DDG 摘要。"""
    try:
        from urllib.parse import urlparse
        domain = urlparse(url).netloc.lstrip("www.")
        if any(domain.endswith(d) for d in _SKIP_FETCH_DOMAINS):
            return None
        resp = S.get(url, timeout=10, allow_redirects=True, verify=False)
        if resp.status_code != 200:
            return None
        # 去除 HTML 标签
        text = re.sub(r"<[^>]+>", " ", resp.text)
        text = re.sub(r"\s+", " ", text).strip()
        if keyword.lower() not in text.lower():
            return None
        return extract_context(text, keyword, window=300)
    except Exception:
        return None


# ══════════════════════════════════════════════════════════════════
# API 类源（直接 HTTP）
# ══════════════════════════════════════════════════════════════════

def search_gitlab(keyword, token):
    """GitLab 仓库搜索（blobs scope 对免费账号禁用，改用 projects scope）。"""
    findings = []
    resp = get(
        "https://gitlab.com/api/v4/search",
        headers={"PRIVATE-TOKEN": token},
        params={"scope": "projects", "search": keyword, "per_page": 20}
    )
    if not resp or resp.status_code != 200:
        log(f"    GitLab HTTP {resp.status_code if resp else 'err'}")
        return findings
    for item in (resp.json() or [])[:20]:
        name = item.get("name_with_namespace", "")
        desc = (item.get("description") or "")[:200]
        url  = item.get("web_url", "")
        snippet = f"[仓库] {name} — {desc}" if desc else f"[仓库] {name}"
        findings.append({"source_id": "gitlab_api", "source_name": "GitLab",
                         "keyword": keyword, "url": url, "snippet": snippet})
    return findings


def search_gitee(keyword, token):
    """Gitee 代码搜索（web 页面 + private_token）。"""
    findings = []
    try:
        resp = S.get("https://search.gitee.com/",
                     params={"type": "codes", "q": keyword, "private_token": token},
                     timeout=30)
    except Exception as e:
        log(f"    Gitee 连接失败: {e}")
        return findings
    if not resp or resp.status_code != 200:
        log(f"    Gitee HTTP {resp.status_code if resp else 'err'}")
        return findings

    html = resp.text
    # 提取结果链接
    links = re.findall(r'href="(https://gitee\.com/[^"]+/blob/[^"]+)"', html)
    # 提取代码片段（去 HTML 标签）
    raw_snippets = re.findall(
        r'<div[^>]*class="[^"]*highlight[^"]*"[^>]*>(.*?)</div>',
        html, re.DOTALL
    )
    snippets = [re.sub(r'<[^>]+>', '', s).strip()[:300] for s in raw_snippets]

    for i, link in enumerate(links[:10]):
        snippet = snippets[i] if i < len(snippets) else ""
        findings.append({"source_id": "gitee_search", "source_name": "Gitee",
                         "keyword": keyword, "url": link, "snippet": snippet})
    return findings


def search_psbdmp(keyword):
    """psbdmp.ws Pastebin 存档搜索。"""
    findings = []
    # psbdmp.ws SSL 证书有问题，关闭验证
    try:
        resp = S.get(
            f"https://psbdmp.ws/search/{quote(keyword, safe='')}",
            timeout=15, verify=False
        )
    except Exception as e:
        log(f"    psbdmp.ws 连接失败: {e}")
        return findings
    if not resp or resp.status_code != 200:
        return findings

    paste_ids = re.findall(r'href="/([A-Za-z0-9]{8})"', resp.text)
    for pid in paste_ids[:8]:
        time.sleep(1)
        raw = get(f"https://pastebin.com/raw/{pid}")
        if raw and raw.status_code == 200 and keyword.lower() in raw.text.lower():
            snippet = extract_context(raw.text, keyword)
            findings.append({
                "source_id": "psbdmp", "source_name": "psbdmp.ws / Pastebin",
                "keyword": keyword,
                "url": f"https://pastebin.com/{pid}",
                "snippet": snippet[:300]
            })
    return findings


def search_grep_app(keyword):
    """Grep.app 跨库全文搜索（JSON API）。"""
    findings = []
    resp = get("https://grep.app/api/search",
               headers={"Accept": "application/json"},
               params={"q": keyword})
    if not resp:
        return findings
    if resp.status_code == 429:
        log("    grep.app 速率限制，跳过")
        return findings
    try:
        hits = resp.json().get("hits", {}).get("hits", [])
        for h in hits[:10]:
            repo  = h.get("repo", {}).get("raw", "")
            fpath = h.get("path", {}).get("raw", "")
            body  = h.get("content", {}).get("raw", "")[:300]
            url   = f"https://github.com/{repo}/blob/HEAD/{fpath}"
            findings.append({"source_id": "grep_app", "source_name": "Grep.app",
                             "keyword": keyword, "url": url, "snippet": body})
    except Exception:
        pass
    return findings


# ══════════════════════════════════════════════════════════════════
# Search 类源（DuckDuckGo，免费无需 Key）
# ══════════════════════════════════════════════════════════════════

def search_ddg(dork, source_id, source_name, keyword, max_results=5):
    """通过 DuckDuckGo HTML 后端执行 Dork（强制 html，不走 Yahoo/Yandex/Brave）。
    拿到 URL 后尝试 fetch 完整内容提取片段，失败则回退到 DDG 摘要。"""
    findings = []
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(dork, max_results=max_results, backend="html"))
        for r in results:
            url        = r.get("href", "")
            ddg_snippet = r.get("body", "")[:300]
            combined   = (url + " " + ddg_snippet).lower()
            if keyword.lower() not in combined:
                continue

            # 尝试 fetch 页面拿更完整的片段
            time.sleep(1)
            fetched = fetch_snippet(url, keyword)
            snippet = fetched if fetched else ddg_snippet

            findings.append({
                "source_id":      source_id,
                "source_name":    source_name,
                "keyword":        keyword,
                "url":            url,
                "snippet":        snippet,
                "snippet_source": "fetch" if fetched else "ddg",
            })
    except Exception as e:
        log(f"    DDG [{source_name}] 失败: {type(e).__name__}")
    return findings


# ══════════════════════════════════════════════════════════════════
# 主执行逻辑
# ══════════════════════════════════════════════════════════════════

def run(target_config, sources, credentials):
    watch_kws    = target_config.get("watch_keywords", {})
    source_tiers = target_config.get("source_tiers", {})
    gl_token     = credentials.get("gitlab_token", "")
    gt_token     = credentials.get("gitee_token", "")

    # 加载已见记录（去重用）
    seen = load_json(SEEN_FILE) if SEEN_FILE.exists() else {}

    all_findings   = []   # 本次全部新发现
    stats          = {"searched": 0, "hits": 0, "new": 0}

    for tier in ["T1_internal", "T2_brand", "T3_generic"]:
        keywords = watch_kws.get(tier, [])
        if not keywords:
            continue

        # 按 tier 过滤允许的 source IDs
        allowed = source_tiers.get(tier, "all")
        tier_sources = sources if allowed == "all" \
                       else [s for s in sources if s["id"] in allowed]

        log(f"\n{'='*60}")
        log(f"{tier}：{len(keywords)} 词 × {len(tier_sources)} 源")

        for keyword in keywords:
            log(f"\n  ▶ [{keyword}]")

            for source in tier_sources:
                sid    = source["id"]
                sname  = source["name"]
                method = source.get("method", "search")
                tmpl   = source.get("template", "")
                stats["searched"] += 1
                time.sleep(5 if method == "search" else 2)

                # ── API 类 ──────────────────────────────────────
                if method == "api":
                    if sid == "gitlab_api":
                        raw = search_gitlab(keyword, gl_token) if gl_token else []
                    elif sid == "gitee_search":
                        raw = search_gitee(keyword, gt_token) if gt_token else []
                    elif sid == "psbdmp":
                        raw = search_psbdmp(keyword)
                    elif sid == "grep_app":
                        raw = search_grep_app(keyword)
                        time.sleep(3)
                    else:
                        continue

                # ── Search 类（DuckDuckGo）──────────────────────
                elif method == "search":
                    dork = tmpl.replace("{keyword}", keyword)
                    raw  = search_ddg(dork, sid, sname, keyword)

                else:
                    continue

                if not raw:
                    continue

                log(f"    {sname}: {len(raw)} 条命中")
                stats["hits"] += len(raw)

                # 去重，只留新发现
                for f in raw:
                    fid_val = fid(f["url"], f["keyword"], f["snippet"])
                    if fid_val not in seen:
                        seen[fid_val] = {"first_seen": ts(), "url": f["url"]}
                        f.update({"id": fid_val, "tier": tier,
                                  "first_seen": ts(), "dork": tmpl.replace("{keyword}", keyword)})
                        all_findings.append(f)
                        stats["new"] += 1

    # 保存更新后的已见记录
    save_json(SEEN_FILE, seen)
    return all_findings, stats


# ══════════════════════════════════════════════════════════════════
# 结果输出
# ══════════════════════════════════════════════════════════════════

def write_results(findings, stats, target_config, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    stamp  = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = target_config.get("target", {})

    result = {
        "target":    target,
        "scan_time": ts(),
        "stats":     stats,
        "findings":  findings,
    }

    # JSON 原始结果
    json_path = out_dir / f"results_{stamp}.json"
    save_json(json_path, result)
    log(f"\n结果已写入：{json_path}")

    # Markdown 简报
    md_path = out_dir / f"results_{stamp}.md"
    lines   = [
        f"# 泄漏监控结果",
        f"",
        f"**目标**：{target.get('name','')} | `{target.get('domain','')}`",
        f"**扫描时间**：{ts()}",
        f"**统计**：执行 {stats['searched']} 次查询，命中 {stats['hits']} 条，新发现 {stats['new']} 条",
        f"",
        f"---",
        f"",
    ]

    if not findings:
        lines.append("本次扫描无新发现。")
    else:
        # 按 tier 分组输出
        for tier in ["T1_internal", "T2_brand", "T3_generic"]:
            tier_items = [f for f in findings if f.get("tier") == tier]
            if not tier_items:
                continue
            lines += [f"## {tier}（{len(tier_items)} 条）", ""]
            for f in tier_items:
                lines += [
                    f"### {f['source_name']} — `{f['keyword']}`",
                    f"",
                    f"| 字段 | 值 |",
                    f"|------|----|",
                    f"| 来源 | {f['source_name']} |",
                    f"| URL | {f['url']} |",
                    f"| 关键词 | `{f['keyword']}` |",
                    f"| 发现时间 | {f['first_seen']} |",
                    f"",
                    f"**片段**：",
                    f"```",
                    f"{f['snippet'][:300]}",
                    f"```",
                    f"",
                ]

    md_path.write_text("\n".join(lines), encoding="utf-8")
    log(f"报告已写入：{md_path}")
    return json_path, md_path


# ══════════════════════════════════════════════════════════════════
# 入口
# ══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="corp-leak-intel 监控脚本")
    parser.add_argument("--target",      default=None)
    parser.add_argument("--credentials", default=str(CREDS_FILE))
    parser.add_argument("--out",         default=str(DEFAULT_OUT))
    args = parser.parse_args()

    # 自动查找 target.json
    target_path = Path(args.target) if args.target else None
    if not target_path:
        for c in [DEFAULT_OUT / "unionpay_target.json", BASE_DIR / "target.json"]:
            if c.exists():
                target_path = c
                break
    if not target_path or not target_path.exists():
        sys.exit("[错误] 未找到 target.json，请用 --target 指定")

    log(f"目标配置 : {target_path}")
    log(f"结果输出 : {args.out}")

    target_config = load_json(target_path)
    sources       = load_json(SOURCES_FILE)
    creds_path    = Path(args.credentials)
    credentials   = load_json(creds_path) if creds_path.exists() else {}

    if not credentials:
        log("⚠️  未找到 .credentials.json，GitLab/Gitee 将跳过")

    findings, stats = run(target_config, sources, credentials)
    write_results(findings, stats, target_config, args.out)

    log(f"\n完成：新发现 {stats['new']} 条 / 命中 {stats['hits']} 条 / 查询 {stats['searched']} 次")


if __name__ == "__main__":
    main()
