#!/usr/bin/env python3
"""
corp-leak-intel Report Builder
企业信息泄漏情报报告生成器

用法：
    python3 report_builder.py --input evidence.json --output report_20240101.md
    python3 report_builder.py --input evidence.json  # 输出到 stdout

evidence.json 格式：
{
  "target": {
    "company_name": "Acme Corp",
    "company_name_cn": "艾克公司",
    "domain": "acme.com",
    "email_format": "@acme.com",
    "github_org": "acme-corp",
    "product_names": ["AcmeCloud", "AcmeAPI"],
    "scan_time": "2024-01-01T12:00:00Z"
  },
  "stats": {
    "sources_searched": 42,
    "dorks_executed": 87,
    "pages_fetched": 23,
    "evidence_collected": 15
  },
  "findings": [
    {
      "id": "F001",
      "risk": "high",           # "high" | "medium" | "low"
      "category": "credential", # "credential" | "internal" | "mention"
      "source_name": "GitHub",
      "source_category": "代码仓库",
      "url": "https://github.com/...",
      "date_found": "2024-01-01",
      "date_published": "2023-06-15",  # 可选
      "dork_used": "site:github.com \"acme.com\" filename:.env",
      "snippet": "API_KEY=sk-xxxx...",  # ≤300字符，已脱敏
      "raw_match": "API_KEY=sk-AbCd1234****",  # 实际匹配内容（已脱敏）
      "risk_reason": "硬编码 OpenAI API Key，前缀 sk-，长度符合真实 key 特征",
      "action": "立即在 OpenAI 控制台撤销该 Key；审计 API 调用日志"
    }
  ],
  "no_findings": [
    {"source": "Pastebin", "dork": "site:pastebin.com \"acme.com\"", "note": "0 结果"}
  ]
}
"""

import json
import sys
import argparse
import re
from datetime import datetime
from pathlib import Path


# ── 风险等级配置 ────────────────────────────────────────────────
RISK_CONFIG = {
    "high": {
        "emoji": "🔴",
        "label": "高风险 —— 凭据 / 密钥泄漏",
        "sort_order": 0,
    },
    "medium": {
        "emoji": "🟡",
        "label": "中风险 —— 内部信息暴露",
        "sort_order": 1,
    },
    "low": {
        "emoji": "🟢",
        "label": "低风险 / 一般提及",
        "sort_order": 2,
    },
}


# ── 敏感信息脱敏 ────────────────────────────────────────────────
REDACT_PATTERNS = [
    # AWS Key
    (r"AKIA[A-Z0-9]{16}", lambda m: m.group()[:8] + "****"),
    # GitHub PAT
    (r"ghp_[A-Za-z0-9]{36}", lambda m: m.group()[:8] + "****"),
    # OpenAI Key
    (r"sk-[A-Za-z0-9]{40,}", lambda m: m.group()[:6] + "****"),
    # Generic Base64-ish secrets (40+ chars)
    (r"(?<=['\"])[A-Za-z0-9+/]{40,}={0,2}(?=['\"])", lambda m: m.group()[:8] + "****"),
    # Passwords in connection strings
    (r"(://[^:]+:)([^@]{4,})(@)", lambda m: m.group(1) + "****" + m.group(3)),
    # password= assignments
    (r"(password\s*[=:]\s*['\"]?)(\S{4,})(['\"]?)", lambda m: m.group(1) + "****" + m.group(3), re.IGNORECASE),
]


def redact(text: str) -> str:
    """对文本中的敏感信息进行脱敏处理。"""
    for pattern_args in REDACT_PATTERNS:
        if len(pattern_args) == 3:
            pattern, repl, flags = pattern_args
            text = re.sub(pattern, repl, text, flags=flags)
        else:
            pattern, repl = pattern_args
            text = re.sub(pattern, repl, text)
    return text


def truncate(text: str, max_len: int = 300) -> str:
    """截断文本至最大长度。"""
    text = text.strip()
    if len(text) > max_len:
        return text[:max_len - 3] + "..."
    return text


# ── 自动风险分类（当 JSON 中 risk 字段缺失时使用）─────────────────
HIGH_RISK_PATTERNS = [
    r"AKIA[A-Z0-9]{16}",                          # AWS Access Key
    r"ghp_[A-Za-z0-9]{36}",                       # GitHub PAT
    r"sk-[A-Za-z0-9]{40,}",                       # OpenAI Key
    r"-----BEGIN\s+(?:RSA\s+)?PRIVATE KEY-----",  # 私钥
    r"mongodb\+srv://|mysql://|postgresql://|redis://", # DB URL
    r"(?:password|passwd|pwd)\s*[=:]\s*\S{6,}",  # 硬编码密码
    r"(?:api_key|apikey|secret_key|access_token)\s*[=:]\s*\S{8,}", # API Key
    r"[A-Za-z0-9+/]{40,}={0,2}",                 # Base64 密钥
]

MEDIUM_RISK_PATTERNS = [
    r"10\.\d{1,3}\.\d{1,3}\.\d{1,3}",            # 内网 IP
    r"192\.168\.\d{1,3}\.\d{1,3}",               # 内网 IP
    r"172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}", # 内网 IP
    r"internal|confidential|staging|prod-\w+",   # 内部标签
    r"@\w+\.local|\.internal\b",                  # 内部域名
]


def auto_classify_risk(snippet: str) -> str:
    """根据 snippet 内容自动判断风险等级。"""
    for pattern in HIGH_RISK_PATTERNS:
        if re.search(pattern, snippet, re.IGNORECASE):
            return "high"
    for pattern in MEDIUM_RISK_PATTERNS:
        if re.search(pattern, snippet, re.IGNORECASE):
            return "medium"
    return "low"


# ── 报告生成 ────────────────────────────────────────────────────
def build_header(data: dict) -> str:
    target = data.get("target", {})
    stats = data.get("stats", {})
    findings = data.get("findings", [])

    high_count = sum(1 for f in findings if f.get("risk") == "high")
    medium_count = sum(1 for f in findings if f.get("risk") == "medium")
    low_count = sum(1 for f in findings if f.get("risk") == "low")

    scan_time = target.get("scan_time", datetime.now().isoformat())
    try:
        dt = datetime.fromisoformat(scan_time.replace("Z", "+00:00"))
        scan_time_fmt = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        scan_time_fmt = scan_time

    company_display = target.get("company_name", "N/A")
    if cn := target.get("company_name_cn"):
        company_display += f" / {cn}"

    lines = [
        "# 企业信息泄漏情报报告",
        "",
        f"**目标**：{company_display}",
        f"**主域名**：`{target.get('domain', 'N/A')}`",
        f"**邮箱格式**：`{target.get('email_format', 'N/A')}`",
        f"**GitHub Org**：`{target.get('github_org', 'N/A')}`",
        f"**生成时间**：{scan_time_fmt}",
        f"**执行范围**：{stats.get('sources_searched', '?')} 个情报源 | {stats.get('dorks_executed', '?')} 条 Dork | 抓取页面 {stats.get('pages_fetched', '?')} 个",
        f"**风险汇总**：🔴 {high_count} 条高风险 | 🟡 {medium_count} 条中风险 | 🟢 {low_count} 条低风险",
        "",
        "> **免责声明**：本报告由被动情报收集生成，未对目标系统发起任何主动连接。仅供授权安全评估使用。",
        "",
        "---",
        "",
    ]
    return "\n".join(lines)


def build_summary(data: dict) -> str:
    findings = data.get("findings", [])
    high = [f for f in findings if f.get("risk") == "high"]
    medium = [f for f in findings if f.get("risk") == "medium"]

    lines = ["## 执行摘要", ""]

    if not findings:
        lines.append("在本次扫描范围内，**未发现**与目标相关的明显信息泄漏。建议定期重复扫描以监控新增泄漏。")
    else:
        if high:
            sources = list({f.get("source_name", "未知") for f in high})
            lines.append(f"发现 **{len(high)} 条高风险泄漏**，涉及来源：{', '.join(sources)}。")
            lines.append("**建议立即处置**：轮换相关凭据并审计访问日志。")
        if medium:
            sources = list({f.get("source_name", "未知") for f in medium})
            lines.append(f"发现 **{len(medium)} 条中风险内部信息暴露**，涉及来源：{', '.join(sources)}。")
        if not high and not medium:
            lines.append("未发现高风险或中风险泄漏，存在少量一般性提及，建议持续监控。")

    lines += ["", "---", ""]
    return "\n".join(lines)


def build_finding_block(finding: dict, idx: int) -> str:
    """生成单条 Finding 的 Markdown 块。"""
    risk = finding.get("risk", auto_classify_risk(finding.get("snippet", "")))
    cfg = RISK_CONFIG.get(risk, RISK_CONFIG["low"])

    snippet = redact(truncate(finding.get("snippet", "（无片段）")))
    risk_reason = finding.get("risk_reason", "匹配目标关键词")
    action = finding.get("action", "评估后按内部安全响应流程处置")
    date_published = finding.get("date_published", "未知")
    dork_used = finding.get("dork_used", "")

    lines = [
        f"### [{finding.get('id', f'F{idx:03d}')}] {finding.get('source_name', '未知来源')} — {finding.get('category', '未分类')}",
        "",
        f"| 字段 | 值 |",
        f"|------|----|",
        f"| **来源** | {finding.get('source_name', 'N/A')}（{finding.get('source_category', 'N/A')}）|",
        f"| **URL** | {finding.get('url', 'N/A')} |",
        f"| **发现时间** | {finding.get('date_found', 'N/A')} |",
        f"| **内容发布时间** | {date_published} |",
        f"| **风险等级** | {cfg['emoji']} {risk.upper()} |",
        "",
        "**证据片段**（已脱敏）：",
        "```",
        snippet,
        "```",
        "",
        f"**风险说明**：{risk_reason}",
        "",
        f"**处置建议**：{action}",
    ]

    if dork_used:
        lines += ["", f"<details><summary>使用的 Dork</summary>", "", f"```", dork_used, "```", "", "</details>"]

    lines += [""]
    return "\n".join(lines)


def build_findings_section(data: dict) -> str:
    findings = data.get("findings", [])
    sections = []

    for risk_key in ["high", "medium", "low"]:
        cfg = RISK_CONFIG[risk_key]
        subset = [f for f in findings if f.get("risk") == risk_key]

        if risk_key == "low":
            # 低风险用简表
            sections.append(f"## {cfg['emoji']} {cfg['label']}\n")
            if not subset:
                sections.append("_本次扫描未发现低风险提及。_\n\n---\n")
                continue

            table_lines = [
                "| 序号 | 来源 | 内容摘要 | URL |",
                "|------|------|----------|-----|",
            ]
            for i, f in enumerate(subset, 1):
                snippet_short = redact(truncate(f.get("snippet", ""), 80))
                url = f.get("url", "N/A")
                table_lines.append(f"| {i} | {f.get('source_name', 'N/A')} | {snippet_short} | {url} |")
            sections.append("\n".join(table_lines))
            sections.append("\n\n---\n")
        else:
            sections.append(f"## {cfg['emoji']} {cfg['label']}\n")
            if not subset:
                sections.append(f"_本次扫描未发现{cfg['label'].split('——')[0].strip()}。_\n\n---\n")
                continue
            for i, f in enumerate(subset, 1):
                sections.append(build_finding_block(f, i))
            sections.append("---\n")

    return "\n".join(sections)


def build_no_findings_section(data: dict) -> str:
    no_findings = data.get("no_findings", [])
    if not no_findings:
        return ""

    lines = [
        "## 未发现记录（已搜索，0 结果）",
        "",
        "| 情报源 | Dork | 备注 |",
        "|--------|------|------|",
    ]
    for nf in no_findings:
        dork = nf.get("dork", "N/A").replace("|", "\\|")
        lines.append(f"| {nf.get('source', 'N/A')} | `{dork}` | {nf.get('note', '0 结果')} |")

    lines += ["", "---", ""]
    return "\n".join(lines)


def build_dork_appendix(data: dict) -> str:
    findings = data.get("findings", [])
    no_findings = data.get("no_findings", [])

    all_dorks = []
    for f in findings:
        if d := f.get("dork_used"):
            all_dorks.append((f.get("source_name", "未知"), d, "命中"))
    for nf in no_findings:
        if d := nf.get("dork"):
            all_dorks.append((nf.get("source", "未知"), d, "0 结果"))

    if not all_dorks:
        return ""

    lines = [
        "## 附录：执行的 Dork 列表",
        "",
        "| 情报源 | Dork | 结果 |",
        "|--------|------|------|",
    ]
    seen = set()
    for source, dork, result in all_dorks:
        key = dork.strip()
        if key in seen:
            continue
        seen.add(key)
        dork_escaped = dork.replace("|", "\\|")
        lines.append(f"| {source} | `{dork_escaped}` | {result} |")

    lines += ["", "---", ""]
    return "\n".join(lines)


def build_report(data: dict) -> str:
    """将 evidence 数据组装为完整 Markdown 报告。"""
    # 自动补全风险分类
    for f in data.get("findings", []):
        if "risk" not in f:
            f["risk"] = auto_classify_risk(f.get("snippet", ""))

    parts = [
        build_header(data),
        build_summary(data),
        build_findings_section(data),
        build_no_findings_section(data),
        build_dork_appendix(data),
        "_本报告由 `corp-leak-intel` Skill 自动生成。仅供授权安全评估使用。_\n",
    ]
    return "\n".join(parts)


# ── CLI 入口 ────────────────────────────────────────────────────
def main():
    if "--test" in sys.argv:
        _test()
        sys.exit(0)

    parser = argparse.ArgumentParser(
        description="corp-leak-intel 报告生成器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--input", "-i", required=True, help="evidence JSON 文件路径")
    parser.add_argument("--output", "-o", help="输出 Markdown 文件路径（不指定则输出到 stdout）")
    parser.add_argument("--redact", action="store_true", default=True, help="对敏感信息脱敏（默认开启）")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"[错误] 输入文件不存在：{input_path}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(input_path, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        print(f"[错误] JSON 解析失败：{e}", file=sys.stderr)
        sys.exit(1)

    report = build_report(data)

    if args.output:
        out_path = Path(args.output)
        out_path.write_text(report, encoding="utf-8")
        print(f"[完成] 报告已写入：{out_path}")
        findings = data.get("findings", [])
        high = sum(1 for f in findings if f.get("risk") == "high")
        medium = sum(1 for f in findings if f.get("risk") == "medium")
        low = sum(1 for f in findings if f.get("risk") == "low")
        print(f"[统计] 🔴 {high} 条高风险 | 🟡 {medium} 条中风险 | 🟢 {low} 条低风险")
    else:
        print(report)


# ── 内联测试 ────────────────────────────────────────────────────
def _test():
    """运行内联测试：python3 report_builder.py  （需添加 --test 参数）"""
    sample = {
        "target": {
            "company_name": "Acme Corp",
            "company_name_cn": "艾克公司",
            "domain": "acme.com",
            "email_format": "@acme.com",
            "github_org": "acme-corp",
            "scan_time": "2024-01-01T08:00:00Z",
        },
        "stats": {
            "sources_searched": 12,
            "dorks_executed": 25,
            "pages_fetched": 8,
            "evidence_collected": 3,
        },
        "findings": [
            {
                "id": "F001",
                "risk": "high",
                "category": "credential",
                "source_name": "GitHub",
                "source_category": "代码仓库",
                "url": "https://github.com/some-user/some-repo/blob/main/.env",
                "date_found": "2024-01-01",
                "date_published": "2023-09-10",
                "dork_used": 'site:github.com "acme.com" filename:.env',
                "snippet": 'OPENAI_API_KEY=sk-AbCd1234EfGh5678IjKl9012MnOp3456QrSt7890UvWx\nDB_PASSWORD=SuperSecret123!',
                "risk_reason": "硬编码 OpenAI API Key（sk- 前缀），疑似真实生产凭据",
                "action": "立即在 OpenAI 控制台撤销该 Key；强制 rotate 数据库密码",
            },
            {
                "id": "F002",
                "risk": "medium",
                "category": "internal",
                "source_name": "Pastebin",
                "source_category": "粘贴板",
                "url": "https://pastebin.com/xXxXxXxX",
                "date_found": "2024-01-01",
                "dork_used": 'site:pastebin.com "acme.com" "internal"',
                "snippet": "Acme Corp internal deployment checklist\nStaging server: 10.0.1.45\nAdmin: john.doe@acme.com",
                "risk_reason": "包含内网 IP 和员工真实邮箱，疑似内部运维文档外泄",
                "action": "确认文档来源；通知 IT 安全团队；评估是否需申请下架",
            },
            {
                "id": "F003",
                "risk": "low",
                "category": "mention",
                "source_name": "Reddit",
                "source_category": "论坛",
                "url": "https://reddit.com/r/sysadmin/comments/xxx",
                "date_found": "2024-01-01",
                "dork_used": 'site:reddit.com "Acme Corp" "breach"',
                "snippet": "Has anyone had issues with Acme Corp's cloud service? Their support is slow.",
                "risk_reason": "普通用户讨论，无敏感信息",
                "action": "记录存档，无需立即行动",
            },
        ],
        "no_findings": [
            {"source": "GitLab", "dork": 'site:gitlab.com "acme.com" filename:.env', "note": "0 结果"},
            {"source": "Gitee", "dork": 'site:gitee.com "acme.com" "password"', "note": "0 结果"},
        ],
    }

    report = build_report(sample)
    print(report)
    print("\n[测试通过] 报告生成成功")


if __name__ == "__main__":
    main()
